import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Select Mode"),
        backgroundColor: Colors.lightBlue,
      ),
      body: Center(
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            fixedSize: const Size(200, 200), // Kích thước hình vuông
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16), // Bo góc
            ),
            backgroundColor: Colors.blueAccent, // Màu nền nút
            foregroundColor: Colors.white, // Màu chữ và icon
            shadowColor: Colors.black, // Màu bóng
            elevation: 8, // Độ nổi của nút
          ),
          onPressed: () => _showModeSelector(context),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(
                Icons.settings, // Biểu tượng
                size: 60, // Kích thước icon
              ),
              SizedBox(height: 10),
              Text(
                "Select Mode", // Dòng chữ
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showModeSelector(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.wifi, color: Colors.blue),
                title: const Text("Access Point Mode"),
                onTap: () {
                  Navigator.pop(context);
                  _setMode(context, "Access Point");
                },
              ),
              ListTile(
                leading: const Icon(Icons.cable, color: Colors.green),
                title: const Text("LAN Mode"),
                onTap: () {
                  Navigator.pop(context);
                  _setMode(context, "LAN");
                },
              ),
              ListTile(
                leading: const Icon(Icons.bluetooth, color: Colors.teal),
                title: const Text("BLE Mode"),
                onTap: () {
                  Navigator.pop(context);
                  _setMode(context, "BLE");
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _setMode(BuildContext context, String mode) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Switched to $mode mode"),
        duration: const Duration(seconds: 2),
      ),
    );
    // TODO: Thực hiện hành động thay đổi trạng thái cho board ở đây.
  }
}
